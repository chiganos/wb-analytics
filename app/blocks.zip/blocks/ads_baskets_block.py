# app/blocks/ads_baskets_block.py
import sqlite3
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import io
import base64

def analyze_ads_baskets(db_path, article):
    conn = sqlite3.connect(db_path)
    ads = pd.read_sql("SELECT * FROM ads", conn, parse_dates=["date"])
    funnel = pd.read_sql("SELECT * FROM funnel", conn, parse_dates=["date"])
    conn.close()

    ads = ads[ads["article"] == article]
    funnel = funnel[funnel["article"] == article]

    df = ads.merge(funnel, on=["article", "date"], how="inner")
    df = df[df["shows"] > 200]

    if df.empty:
        return "<p>❗ Нет данных после объединения по article и date.</p>", ""

    corr = df["baskets"].corr(df["cart_add"])

    # График
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.scatter(df["baskets"], df["cart_add"], label="Данные")
    m, b = pd.Series(df["baskets"]).corr(df["cart_add"]), df["cart_add"].mean()
    x_vals = df["baskets"]
    ax.plot(x_vals, m * x_vals + b, color="red", label="Линейная регрессия")
    ax.set_xlabel("Добавления в корзину по рекламе (baskets)")
    ax.set_ylabel("Общие добавления в корзину (cart_add)")
    ax.set_title(f"Корреляция baskets → cart_add\nАртикул {article}, r = {corr:.2f}")
    ax.legend()
    ax.grid(True)

    buf = io.BytesIO()
    plt.tight_layout()
    plt.savefig(buf, format="png")
    plt.close(fig)
    buf.seek(0)
    image_base64 = base64.b64encode(buf.read()).decode("utf-8")

    trend_text = (
        "✅ Сильная положительная связь — реклама сильно влияет на добавления"
        if corr > 0.6 else
        "➕ Умеренная связь"
        if corr > 0.3 else
        "⚠️ Связь слабая или отсутствует"
    )

    html = f"""
    <p><b>📊 Анализ рекламы: baskets → cart_add</b><br>
    🔍 <b>Корреляция:</b> {corr:.2f}<br>
    {trend_text}<br>
    Дней с показами > 200: {len(df)}
    </p>
    <img src="data:image/png;base64,{image_base64}" style="max-width:100%; height:auto;">
    """

    context_text = (
        f"\n📊 Влияние рекламы (baskets → cart_add):\n"
        f"- Корреляция: {corr:.2f}\n"
        f"- Дней с показами > 200: {len(df)}\n"
        f"- Вывод: {trend_text}"
    )

    return html, context_text
