import os
from openai import OpenAI
from datetime import datetime, timedelta
from app.routes.init_context import context_by_article
import sqlite3
import pandas as pd

# 🔑 Ключ — временно прямым текстом (по желанию можно через env)
client = OpenAI(api_key="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")

DB_PATH = os.path.join(os.path.dirname(__file__), "../../wb.db")
conn = sqlite3.connect(DB_PATH)
funnel = pd.read_sql("SELECT * FROM funnel", conn)
ads = pd.read_sql("SELECT * FROM ads", conn)
funnel["date"] = pd.to_datetime(funnel["date"])
ads["date"] = pd.to_datetime(ads["date"])
conn.close()

def append_recent_metrics_if_needed(question: str, article: str, context: str) -> str:
    keywords = ["динамика", "снижение", "последние дни", "тренд", "просели", "падает", "упали", "почему меньше"]
    if any(kw in question.lower() for kw in keywords):
        try:
            recent = funnel[(funnel['article'] == int(article)) & (funnel['date'] >= datetime.now() - timedelta(days=7))]
            prev = funnel[(funnel['article'] == int(article)) & 
                          (funnel['date'] < datetime.now() - timedelta(days=7)) &
                          (funnel['date'] >= datetime.now() - timedelta(days=14))]

            orders_recent = recent['orders'].sum()
            orders_prev = prev['orders'].sum()
            avg_price_recent = recent['price'].mean()
            avg_conversion = recent['cart_to_order_conv'].mean()

            trend = "⬇️ падение" if orders_recent < orders_prev else "⬆️ рост"

            dynamic = (
                f"\n📊 Динамика:\n"
                f"- Заказы (посл. 7д): {orders_recent}, пред. 7д: {orders_prev}\n"
                f"- Средняя цена: {avg_price_recent:.0f} ₽\n"
                f"- Конверсия: {avg_conversion:.2%}\n"
                f"- Общий тренд: {trend}"
            )
            return context + "\n\n" + dynamic
        except Exception as e:
            return context + f"\n⚠️ Ошибка при добавлении динамики: {e}"
    return context

def extract_date_block_if_requested(question: str, article: str, context: str) -> str:
    import re
    patterns = [
        r"(\d{1,2})[.\s]?(?:марта|03)", r"(\d{1,2})[.\s]?(?:апреля|04)", r"(\d{1,2})[.\s]?(?:февраля|02)"
    ]
    found_date = None
    year = datetime.now().year

    for pattern in patterns:
        match = re.search(pattern, question.lower())
        if match:
            day = int(match.group(1))
            month = 3 if "мар" in pattern or "03" in pattern else 4 if "апр" in pattern else 2
            try:
                found_date = datetime(year, month, day)
            except: pass
            break

    if not found_date:
        return context

    day_str = found_date.strftime('%Y-%m-%d')
    funnel_day = funnel[(funnel['article'] == int(article)) & (funnel['date'] == day_str)]
    ads_day = ads[(ads['article'] == int(article)) & (ads['date'] == day_str)]

    block = f"\n📅 Данные за {found_date.strftime('%d.%m.%Y')}:\n"

    if not funnel_day.empty:
        row = funnel_day.iloc[0]
        block += (
            f"- Заказы (funnel): {row['orders']}\n"
            f"- Переходы: {row['open_card']}\n"
            f"- В корзину: {row['cart_add']}\n"
            f"- Конверсия: {row['cart_to_order_conv']:.2%}\n"
        )
    else:
        block += "- Нет данных в funnel\n"

    if not ads_day.empty:
        row = ads_day.iloc[0]
        block += (
            f"- Заказы (реклама): {row['orders']}\n"
            f"- Показы: {row['shows']}\n"
            f"- Расходы: {row['cost']} ₽\n"
            f"- CTR: {row['ctr']:.2%}, CPC: {row['cpc']} ₽\n"
        )
    else:
        block += "- Нет данных в ads\n"

    return context + "\n\n" + block

def ask_gpt(article: str, question: str) -> str:
    if article not in context_by_article:
        return "⚠️ Нет context_text для данного артикула."

    context = context_by_article[article]
    context = append_recent_metrics_if_needed(question, article, context)
    context = extract_date_block_if_requested(question, article, context)

    prompt = f"""
Ты — аналитик Wildberries. Анализируй данные и отвечай на вопрос.

📦 Артикул: {article}

📊 Данные:
{context}

❓ Вопрос: {question}

Формат:
1. Краткий вывод
2. Аргументы с цифрами
3. Чёткие рекомендации
"""

    try:
        response = client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "Ты аналитик Wildberries, эксперт по продажам и метрикам."},
                {"role": "user", "content": prompt}
            ]
        )
        return response.choices[0].message.content
    except Exception as e:
        return f"❌ Ошибка при запросе к GPT: {e}"
